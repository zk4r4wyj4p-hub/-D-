import bpy, math, random, os
from mathutils import Vector
from math import sin,cos,pi
OUT='/workspace/aina-model'
random.seed(8)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for d in bpy.data.materials: bpy.data.materials.remove(d)
def mat(name,col,metal=0,rough=.4):
 m=bpy.data.materials.new(name); m.diffuse_color=(*col,1); m.use_nodes=True
 p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*col,1); p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough
 return m
skin=mat('Porcelain • warm skin',(.83,.58,.52),0,.47)
hair=mat('Moon silver • lavender',(.58,.55,.74),.2,.28)
high=mat('Silver strand highlights',(.86,.82,.96),.25,.25)
black=mat('Midnight satin',(.018,.014,.028),.15,.3)
ruff=mat('Ruffle • plum black',(.034,.022,.045),.08,.4)
edge=mat('Lilac hem piping',(.16,.115,.21),.35,.3)
boot=mat('Obsidian patent leather',(.012,.012,.02),.55,.22)
gold=mat('Antique gold',(.68,.39,.12),.75,.25)
white=mat('Eye whites',(.94,.88,.86),0,.22)
red=mat('Ruby iris',(.55,.015,.045),.25,.23)
blue=mat('Sapphire iris',(.025,.29,.65),.25,.23)
dark=mat('Lashes and pupils',(.009,.005,.015),0,.4)
lip=mat('Rose lip',(.46,.12,.17),0,.4)
gem=mat('Garnet pendant',(.23,.015,.035),.65,.19)
parts=[]
def finish(o,name,ma,bone=None):
 o.name=name;o.data.materials.append(ma)
 if o.type=='MESH':
  for p in o.data.polygons:p.use_smooth=True
 if bone: parts.append((o,bone))
 return o
def uv(name,loc,scale,ma,bone=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=20,location=loc);o=bpy.context.object;o.scale=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return finish(o,name,ma,bone)
def mesh(name,v,f,ma,bone=None,sub=0):
 d=bpy.data.meshes.new(name);d.from_pydata(v,[],f);d.update();o=bpy.data.objects.new(name,d);bpy.context.collection.objects.link(o);finish(o,name,ma,bone)
 if sub:
  m=o.modifiers.new('Silhouette smoothing','SUBSURF');m.levels=sub
 return o
def line(name,pts,r,ma,bone=None):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.bevel_depth=r;c.bevel_resolution=3
 s=c.splines.new('BEZIER');s.bezier_points.add(len(pts)-1)
 for p,co in zip(s.bezier_points,pts):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);return finish(o,name,ma,bone)
def rings(name,rows,ma,bone=None,n=48,sub=1):
 v=[]
 for z,rx,ry,cy in rows:
  for i in range(n):
   a=2*pi*i/n;v.append((rx*cos(a),cy+ry*sin(a),z))
 f=[]
 for j in range(len(rows)-1):
  for i in range(n): a=j*n+i;b=j*n+(i+1)%n;f.append((a,b,b+n,a+n))
 f += [tuple(reversed(range(n))),tuple((len(rows)-1)*n+i for i in range(n))]
 return mesh(name,v,f,ma,bone,sub)
def limb(name,a,b,r1,r2,ma,bone):
 a,b=Vector(a),Vector(b);axis=(b-a).normalized();u=axis.cross(Vector((0,1,0))).normalized();v=axis.cross(u);vs=[];N=24
 for t,r in [(0,r1*.5),(.06,r1),(.4,r1*.92),(.8,r2),(1,r2*.65)]:
  p=a.lerp(b,t)
  for i in range(N):vs.append(p+(u*cos(2*pi*i/N)+v*sin(2*pi*i/N))*r)
 fs=[]
 for j in range(4):
  for i in range(N):k=j*N+i;l=j*N+(i+1)%N;fs.append((k,l,l+N,k+N))
 fs.extend([tuple(reversed(range(N))),tuple(4*N+i for i in range(N))]);return mesh(name,vs,fs,ma,bone,1)
# Body and tailored bodice
rings('Body • torso',[(3.3,.48,.28,0),(3.65,.57,.32,0),(4.05,.37,.24,0),(4.5,.53,.32,0),(4.85,.59,.29,0),(5.05,.46,.23,0)],skin,'chest')
rings('Corseted satin bodice',[(3.6,.58,.35,0),(3.8,.49,.3,0),(4.12,.39,.265,0),(4.45,.52,.34,0),(4.72,.57,.35,0)],black,'chest')
uv('Bust left',(-.265,-.125,4.63),(.29,.295,.25),black,'chest');uv('Bust right',(.265,-.125,4.63),(.29,.295,.25),black,'chest')
limb('Neck',(0,0,4.9),(0,0,5.52),.19,.18,skin,'neck')
# head, ears, face
uv('Face',(0,-.025,5.96),(.49,.405,.64),skin,'head')
for s in [-1,1]:uv('Ear',(.46*s,.0,5.9),(.085,.075,.14),skin,'head')
uv('Nose',(0,-.414,5.89),(.055,.073,.09),skin,'head')
line('Upper lip',[(-.105,-.405,5.66),(0,-.434,5.67),(.105,-.405,5.66)],.014,lip,'head')
line('Lower lip',[(-.075,-.41,5.646),(0,-.426,5.628),(.075,-.41,5.646)],.009,lip,'head')
eyes=[]
for s,ma in [(-1,red),(1,blue)]:
 x=s*.215;z=6.015
 eyes.append(uv('Eye white '+str(s),(x,-.384,z),(.172,.064,.112),white,'head'))
 eyes.append(uv('Iris '+str(s),(x,-.444,z),(.071,.021,.087),ma,'head'))
 eyes.append(uv('Pupil '+str(s),(x,-.463,z),(.032,.008,.063),dark,'head'))
 eyes.append(uv('Eye glint '+str(s),(x-.022,-.473,z+.036),(.021,.008,.024),white,'head'))
 line('Upper eyeliner',[(x-.169,-.4,z),(x-.09,-.442,z+.095),(x+.035,-.447,z+.105),(x+.163,-.4,z+.027)],.018,dark,'head')
 line('Lower eyeliner',[(x-.15,-.401,z-.015),(x,-.44,z-.096),(x+.15,-.405,z-.018)],.007,dark,'head')
 line('Eyebrow',[(x-.12,-.365,6.2),(x,-.4,6.235),(x+.11,-.36,6.21)],.017,hair,'head')
 for j in range(3):
  xx=x+s*(.12+j*.017);line('Outer lash',[(xx,-.416,6.06),(xx+s*.047,-.417,6.09+j*.013)],.009,dark,'head')
# Scalp cap: front hairline above eyebrows, lower at back
v=[];f=[];N=64;M=20
for j in range(M+1):
 for i in range(N):
  a=2*pi*i/N;front=max(0,-sin(a));end=2.12-.92*front;th=.015+(end-.015)*j/M
  v.append((.511*sin(th)*cos(a),.025+.433*sin(th)*sin(a),6.01+.658*cos(th)))
for j in range(M):
 for i in range(N):k=j*N+i;l=j*N+(i+1)%N;f.append((k,l,l+N,k+N))
mesh('Silver hair • scalp',v,f,hair,'head',1)
def strand(name,pts,width,depth,ma=hair,bone='head'):
 # Smooth ribbon-like lock with pointed tip
 v=[];N=10
 for j,p in enumerate(pts):
  t=j/(len(pts)-1);w=width*(.55+.45*sin(pi*t))*(1-t**4)+.002
  for i in range(N):
   a=2*pi*i/N;v.append((p[0]+w*cos(a),p[1]+depth*sin(a)*(1-.9*t),p[2]))
 f=[]
 for j in range(len(pts)-1):
  for i in range(N):k=j*N+i;l=j*N+(i+1)%N;f.append((k,l,l+N,k+N))
 mesh(name,v,f,ma,bone,2)
# Long rear locks, distributed around back and sides
for i in range(19):
 a=-.15+(pi+.3)*i/18;x=.44*cos(a);y=.31*sin(a)+.06
 length=2.25+.43*sin(i*1.9)**2
 pts=[(x*.7,y*.8,6.47),(x,y,6.08),(x*1.2,y+.05,5.55),(x*1.4,y+.17,4.95),(x*1.65+.07*sin(i),y+.25,4.25),(x*1.65+.10*sin(i),y+.28,6.38-length),(x*1.42,y+.23,6.25-length)]
 strand('Long silver lock %02d'%i,pts,.10,.065)
 line('Lock sheen %02d'%i,[(p[0]-.025,p[1]-.045,p[2]) for p in pts[:-1]],.008,high,'head')
# Bangs and long face framing locks
for i in range(9):
 x=(i-4)*.105;tip=6.10+.11*abs(i-4)/4+.045*sin(i*2)
 strand('Fringe %02d'%i,[(x*.6,-.22,6.58),(x*.9,-.37,6.46),(x,-.442,6.28),(x+.028,-.455,tip)],.075,.035)
for s in [-1,1]:
 for j in range(2):strand('Face framing lock',[(s*(.39+j*.055),-.22,6.4),(s*(.47+j*.06),-.29,5.96),(s*(.46+j*.08),-.3,5.4),(s*(.53+j*.10),-.31,4.92),(s*(.43+j*.12),-.29,4.55)],.07,.045)
# Hair band and ribbon
line('Velvet headband',[(.505*cos(a),-.08,6.02+.67*sin(a)) for a in [i*pi/32 for i in range(33)]],.042,black,'head')
def bow(name,c,size,bone):
 x,y,z=c
 for s in [-1,1]:
  vs=[(x,y,z),(x+s*size,y-.02,z+size*.58),(x+s*size*1.12,y+.02,z-size*.37),(x+s*.12*size,y-.07,z-.09)]
  o=mesh(name+' loop',vs,[(0,1,2,3)],black,bone);m=o.modifiers.new('Ribbon thickness','SOLIDIFY');m.thickness=.035;m=o.modifiers.new('Soft ribbon edges','BEVEL');m.width=.045;m.segments=3
  strand(name+' tail',[(x+s*.04,y,z),(x+s*.17,y,z-size*.5),(x+s*.27,y+.04,z-size*1.2)],size*.20,.018,black,bone)
 uv(name+' knot',c,(size*.16,.08,size*.18),black,bone)
bow('Hair ribbon',(-.51,-.04,6.26),.4,'head')
# Legs and shoes
for s,side in [(-1,'L'),(1,'R')]:
 x=s*.265
 limb('Stocking thigh '+side,(x,0,3.48),(x,-.015,2.06),.245,.17,ruff,'thigh.'+side)
 limb('Stocking calf '+side,(x,-.015,2.06),(x,.015,.65),.17,.11,ruff,'shin.'+side)
 limb('Boot shaft '+side,(x,.015,.55),(x,-.005,1.75),.145,.185,boot,'shin.'+side)
 uv('Boot foot '+side,(x,-.18,.35),(.185,.385,.20),boot,'foot.'+side)
 uv('Platform sole '+side,(x,-.2,.19),(.19,.37,.075),black,'foot.'+side)
 limb('Heel '+side,(x,.10,.11),(x,.10,.48),.046,.065,boot,'foot.'+side)
 line('Gold boot chevron '+side,[(x-.17,-.115,1.75),(x,-.20,1.52),(x+.17,-.115,1.75)],.033,gold,'shin.'+side)
 for j in range(5):
  z=.49+j*.10;line('Boot lacing',[(x-.08,-.15,z),(x+.08,-.15,z+.08)],.012,edge,'foot.'+side if j<2 else 'shin.'+side)
# Arms with separate sleeves, gloves and modeled fingers
bones_arm={}
for s,side in [(-1,'L'),(1,'R')]:
 shoulder=(s*.57,0,4.86);elbow=(s*.88,-.015,4.16);wrist=(s*1.06,-.08,3.53)
 bones_arm[side]=(shoulder,elbow,wrist)
 limb('Upper arm '+side,shoulder,elbow,.18,.125,skin,'upper_arm.'+side)
 uv('Elbow '+side,elbow,(.127,.13,.13),skin,'forearm.'+side)
 limb('Forearm '+side,elbow,wrist,.13,.085,skin,'forearm.'+side)
 limb('Long glove '+side,(s*.95,-.04,3.97),wrist,.14,.094,black,'forearm.'+side)
 limb('Silver cuff '+side,(s*.955,-.042,3.96),(s*.966,-.047,3.91),.145,.143,high,'forearm.'+side)
 palm=(s*1.095,-.095,3.38);uv('Hand '+side,palm,(.103,.065,.165),skin,'hand.'+side)
 for j in range(4):
  x=s*(1.025+j*.047);ln=[.16,.23,.215,.16][j]
  limb('Finger '+side+str(j),(x,-.095,3.29),(x+s*.025,-.12,3.29-ln),.024,.017,skin,'hand.'+side)
 limb('Thumb '+side,(s*1.01,-.10,3.43),(s*.965,-.16,3.26),.035,.024,skin,'hand.'+side)
 uv('Puff sleeve '+side,(s*.62,0,4.75),(.265,.25,.27),black,'upper_arm.'+side)
 # gathered sleeve edge
 pts=[]
 for j in range(65):
  a=2*pi*j/64;pts.append((s*.67+(.23+.027*cos(12*a))*cos(a),(.23+.027*cos(12*a))*sin(a),4.57+.025*sin(12*a)))
 line('Ruffled sleeve cuff '+side,pts,.04,ruff,'upper_arm.'+side)
 bow('Shoulder bow '+side,(s*.64,-.22,4.88),.15,'upper_arm.'+side)
# Asymmetric layered skirt: front short, back floor-length
N=128
def skirt_xyz(t,a,extra=0,wave=True):
 front=(1-sin(a))/2
 hem=.48+2.20*(front**3)
 z=3.73+(hem-3.73)*t
 rx=.50+.72*t;ry=.32+.39*t
 wav=(.018+.045*t)*cos(18*a) if wave else 0
 return ((rx+extra+wav)*cos(a),(ry+extra+wav)*sin(a)+.05*t,z+.035*t*sin(18*a))
v=[skirt_xyz(j/18,2*pi*i/N) for j in range(19) for i in range(N)];f=[]
for j in range(18):
 for i in range(N):k=j*N+i;l=j*N+(i+1)%N;f.append((k,l,l+N,k+N))
mesh('High-low skirt foundation',v,f,black,'pelvis',1)
for layer in range(7):
 start=layer/7;end=min(1,(layer+1.35)/7);v=[];f=[]
 for j in range(7):
  u=j/6;t=start+(end-start)*u
  for i in range(N):
   a=2*pi*i/N;ex=.025+u*.09+u*.035*cos(24*a);x,y,z=skirt_xyz(t,a,ex);v.append((x,y,z+u*.045*cos(24*a)))
 for j in range(6):
  for i in range(N):k=j*N+i;l=j*N+(i+1)%N;f.append((k,l,l+N,k+N))
 o=mesh('Skirt ruffle tier %02d'%(layer+1),v,f,ruff if layer%2==0 else black,'pelvis',1)
 m=o.modifiers.new('Fabric thickness','SOLIDIFY');m.thickness=.012
 line('Scalloped hem %02d'%layer,[v[6*N+i] for i in range(N)]+[v[6*N]],.009,edge,'pelvis')
# Front corset details
for s in [-1,1]:
 line('Bodice seam',[(s*.31,-.29,4.72),(s*.27,-.305,4.42),(s*.23,-.265,4.12),(s*.32,-.29,3.8)],.012,edge,'chest')
for j in range(4):
 z=3.88+j*.20;y=-.32 if j<2 else -.36
 line('Corset crosslace A',[(-.095,y,z),(.095,y-.015,z+.16)],.012,high,'chest')
 line('Corset crosslace B',[(.095,y,z),(-.095,y-.015,z+.16)],.012,high,'chest')
bow('Waist bow',(0,-.37,3.76),.22,'chest')
line('Necklace chain',[(-.19,-.12,5.25),(-.13,-.25,5.12),(0,-.31,5.03),(.13,-.25,5.12),(.19,-.12,5.25)],.015,gold,'chest')
uv('Necklace garnet',(0,-.33,4.99),(.065,.035,.11),gem,'chest')
# Keep the underlying torso inside the tailored bodice.
for vertex in bpy.data.objects['Body • torso'].data.vertices:
 vertex.co.x *= .87
 vertex.co.y *= .87
# Armature, named bones, rigid accessories and limb deformation
bpy.ops.object.armature_add(enter_editmode=True,location=(0,0,0));rig=bpy.context.object;rig.name='AINA • Animation Rig';eb=rig.data.edit_bones;eb.remove(eb[0])
def bone(n,h,t,parent=None):
 b=eb.new(n);b.head=h;b.tail=t
 if parent:b.parent=eb[parent]
 return b
bone('root',(0,0,0),(0,0,.5));bone('pelvis',(0,0,3.3),(0,0,3.8),'root');bone('chest',(0,0,3.8),(0,0,4.95),'pelvis');bone('neck',(0,0,4.95),(0,0,5.48),'chest');bone('head',(0,0,5.48),(0,0,6.5),'neck')
for s,side in [(-1,'L'),(1,'R')]:
 sh,el,wr=bones_arm[side];bone('upper_arm.'+side,sh,el,'chest');bone('forearm.'+side,el,wr,'upper_arm.'+side);bone('hand.'+side,wr,(s*1.10,-.10,3.20),'forearm.'+side)
 bone('thigh.'+side,(s*.265,0,3.48),(s*.265,-.015,2.06),'pelvis');bone('shin.'+side,(s*.265,-.015,2.06),(s*.265,.015,.65),'thigh.'+side);bone('foot.'+side,(s*.265,.015,.65),(s*.265,-.38,.3),'shin.'+side)
bpy.ops.object.mode_set(mode='OBJECT');rig.show_in_front=True;rig.data.display_type='OCTAHEDRAL'
for o,bn in parts:
 if o.type=='CURVE':
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.convert(target='MESH')
 vg=o.vertex_groups.new(name=bn);vg.add(list(range(len(o.data.vertices))),1,'REPLACE');m=o.modifiers.new('AINA skeleton','ARMATURE');m.object=rig;o.parent=rig
# Seamless idle motion, head turn and gentle greeting arm
scene=bpy.context.scene;scene.frame_start=1;scene.frame_end=120;scene.render.fps=24
for n in ['chest','neck','head','upper_arm.L','upper_arm.R','forearm.L','forearm.R','hand.L','hand.R']:
 p=rig.pose.bones[n];p.rotation_mode='XYZ'
for frame,phase in [(1,0),(31,1),(61,0),(91,-1),(120,0)]:
 for n,rot in {'chest':(.012*phase,0,.012*phase),'head':(.025*phase,.035*phase,.12*phase),'upper_arm.L':(.025*phase,.02*phase,0),'upper_arm.R':(-.025*phase,0,0),'forearm.L':(.025*phase,0,0),'forearm.R':(.02*phase,0,0)}.items():
  p=rig.pose.bones[n];p.rotation_euler=rot;p.keyframe_insert(data_path='rotation_euler',frame=frame,group=n)
# Eye components shrink together for two stylized blinks (eyelids are not fully sculpted)
for o in eyes:
 for fr,sz in [(1,1),(37,1),(40,.07),(43,1),(92,1),(95,.07),(98,1),(120,1)]:
  o.scale.z=sz;o.keyframe_insert(data_path='scale',frame=fr,group='Blink')
rig['Notes']='Stylized reference-inspired first model. FK bones; accessories rigid-weighted. Skirt and long hair need secondary rig/cloth setup for dancing. Idle action included.'
# Stage
stage=mat('Stage • graphite',(.035,.045,.065),.25,.4)
bpy.ops.mesh.primitive_cylinder_add(vertices=96,radius=1.65,depth=.14,location=(0,0,.015));finish(bpy.context.object,'Display plinth',stage)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.065));finish(bpy.context.object,'Studio floor',mat('Backdrop',(.045,.058,.082),0,.65))
world=bpy.data.worlds.new('Twilight studio');scene.world=world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.13,.16,.24,1);world.node_tree.nodes['Background'].inputs[1].default_value=.45
def aim(o,p):o.rotation_euler=(Vector(p)-o.location).to_track_quat('-Z','Y').to_euler()
def light(name,loc,power,color,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.color=color;o.data.shape='DISK';o.data.size=size;aim(o,(0,0,3.7))
light('Key softbox',(-4,-6,9),1100,(.85,.9,1),5);light('Warm fill',(4,-3,5),800,(1,.76,.69),4);light('Silver rim',(2,4,8),1500,(.58,.65,1),3)
bpy.ops.object.camera_add(location=(9,-20,10));cam=bpy.context.object;cam.name='Portrait Camera';aim(cam,(0,0,3.35));cam.data.type='ORTHO';cam.data.ortho_scale=8.0;scene.camera=cam
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False
scene.render.resolution_x=840;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.frame_set(1)
# Organize model and scene into collections
modelcol=bpy.data.collections.new('CHARACTER • Aina');scene.collection.children.link(modelcol)
for o in [rig]+[p[0] for p in parts]:
 for c in list(o.users_collection):c.objects.unlink(o)
 modelcol.objects.link(o)
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.context.view_layer.objects.active=rig
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/Aina_Gothic.blend')
scene.render.filepath=OUT+'/preview.png';bpy.ops.render.render(write_still=True)
# Face portrait
cam.location=(2,-12,6.8);aim(cam,(0,-.03,5.85));cam.data.ortho_scale=2.15
scene.render.resolution_x=800;scene.render.resolution_y=800;scene.render.filepath=OUT+'/portrait.png';bpy.ops.render.render(write_still=True)
print('MODEL_COMPLETE',len(parts),'bound parts',len(rig.data.bones),'bones')
